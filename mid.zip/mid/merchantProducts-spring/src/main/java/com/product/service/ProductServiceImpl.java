package com.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.bean.Product;
import com.product.dao.ProductDao;
import com.product.exception.ProductException;

@Service
public class ProductServiceImpl implements IProductService {
	@Autowired
	ProductDao productDao;	
	
	@Override
	public List<Product> createProduct(Product product) throws ProductException {
		try {
			 productDao.save(product);
		        return productDao.findAll();
		        }catch(Exception exception) {
		            throw new ProductException(exception.getMessage());
		        }
	}

//	@Override
//	public void deleteProduct(int id) throws ProductException {
//		try
//		{
//			productDao.deleteById(id);
//			
//		}
//		catch(Exception exception)
//		{
//			throw new ProductException(exception.getMessage());
//		}
//		
//	}
	
	@Override
	public List<Product> getAllProducts() throws ProductException {
		try
		{
			return productDao.findAll();
		}
		catch(Exception exception)
		{
			throw new ProductException(exception.getMessage());
		}
	}
	
	@Override
	public Product getProductById(int id) throws ProductException {
		try
		{
			return productDao.findById(id).get();
		}
		catch (Exception exception)
		{
			throw new ProductException(exception.getMessage());
		}
		
	}
	
	@Override
	public List<Product> getProductByMid(int mid) throws ProductException {
		try
		{
			return productDao.findByMid(mid);
		}
		catch (Exception exception)
		{
			throw new ProductException(exception.getMessage());
		}
		
	}

//	@Override
//	public List<Product> updateProduct(String id, Product product1) throws ProductException {
//		try
//		{
//			Optional<Product> optional=productDao.findById(id);
//			if(optional.isPresent())
//			{
//				Product product=optional.get();
//				product.setName(product1.getName());
//				product.setModel(product1.getModel());
//				product.setPrice(product1.getPrice());
//				productDao.save(product);
//				return getAllProducts();
//			}
//			else
//			{
//				throw new ProductException("Product with"+id+" not exist");	
//			}
//		}
//			catch(Exception exception) {
//	            throw new ProductException(exception.getMessage());
//			
//	}
//	}
}



