package com.product.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.product.bean.Product;
@Repository
public interface ProductDao extends JpaRepository<Product, Integer> {
//	
	@Query("from Product where mid=:id1")
	List<Product> findByMid(@Param("id1")Integer mid);
//	@Query("from Product where id=:id2")
//	void deleteById(@Param("id2")String id);
//	
}
